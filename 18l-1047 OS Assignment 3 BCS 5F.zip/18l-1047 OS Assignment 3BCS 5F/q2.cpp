#include <semaphore.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <assert.h>
sem_t pA;
sem_t pB;

int main()
{
    char aux[1000];
    char data1[1000];
    char data2[1000];
    char buff1[1000];
    char buff2[1000];
    int pid1, pid2,i=0;
    pid1=fork();
    sem_init(&pA, 1, 1); //1 means semaphore is used for process synchronization
    sem_init(&pB, 1, 0);      //1 means semaphore is used for process synchronization

    if (pid1 < 0)
    {
        printf("Error in creating fork1/n");
    }

    else if (pid1 == 0)
    {
        printf("Process1 is being executed/nReading the File 1 data/n");
        FILE *readdata;
        readdata = fopen("file1.txt","r");
        i = 0;
        if (readdata)
        {
            while (fgets(aux, 1000, (FILE *)readdata) != NULL)
            {
                while (i < sizeof(aux))
                {
                    data1[i] = aux[i];
                    i++;
                }
            }
        }
        printf("Data that is read from file 1 in process 1 is/n%s", data1);
        fclose(readdata);
        sem_wait(&pA);
        printf("Writing the data to buff1 from process1/n");
        strcat(buff1, data1);
        strcat(buff1, "/n");
        printf("Buffer 1 after writing the data from process1 is/n%s", buff1);
        sem_post(&pA);
    }
    else if (pid1 > 0)
    {
        printf("Process 2 is being executed/nReading the File 2 data/n");
        FILE *readdata;
        readdata = fopen("file2.txt","r");
         i = 0;
        if (readdata)
        {
            while (fgets(aux, 1000, (FILE *)readdata) != NULL)
            {
                while (i < sizeof(aux))
                {
                    data2[i] = aux[i];
                    i++;
                }
            }
        }
        printf("Data that is read from file 2 in process 2 is/n%s", data2);
        fclose(readdata);
        sem_wait(&pB);
        printf("Writing the data to buff1 from process2/n");
        strcat(buff1, data2);
        printf("Buffer 1 after writing the data from process 2 is/n%s", buff1);
        sem_post(&pB);
        pid2=fork();
    }
    if (pid2 < 0)
    {
        printf("Error in creating fork2/n");
    }
    else if (pid2 == 0)
    {
        printf("Process 3 is being executed/nWriting the data to buffer 2 from buffer 1/n");
        strcat(buff2, buff1);
    }
    else if (pid2 > 0)
    {
        wait(NULL);
        printf("Process 4 is being executed/nReading the data from buffer 2/nData from buffer 2 is/n%s", buff2);
    }
    return 0;
}
