#include <semaphore.h>
#include <string.h>
#include <pthread.h>
#include<stdio.h>
#include<stdlib.h>
int potentialCPatients=0;
sem_t coronaPatient;
sem_t fluPatient;

void *currPatients(void *param)
{
    potentialCPatients++;
    pthread_exit(NULL); //mb
}
int main(int argc, char **argv)
{
    if (argc < 2)
    {
        printf( "No of patients Not Specified!\n");
        exit(1); //mb
    }

    int N = atoi(argv[1]);

    sem_init(&coronaPatient, 1, 1); //1 means semaphore is used for process synchronization
    sem_init(&fluPatient, 1, 0);      //1 means semaphore is used for process synchronization

    pthread_t patients[N];
    int i=0;
    while (i<N) //infinite
    {
        if (pthread_create(&patients[i], NULL, &currPatients, NULL) == -1)
        {
            printf( "Thread Creation Failed!\n");
            return 0; //mb
        }
        i++;
    }
    i=0;
    while(i<N){
        int patientType=rand()%2;
        if(patientType==1){
            sem_post(&coronaPatient);
            potentialCPatients--;
            int test;
            int test1=rand()%2;
                if(test1==0){
                 int test2=rand()%2;
                if(test2==0)
                sem_wait(&coronaPatient);
                
        }
            
        }
        else if(patientType==0){
            sem_post(&fluPatient);
            potentialCPatients--;
        }
        i++;
    }
    i=0;
    for (; i < N; i++)
         pthread_join(patients[i], NULL); //mb
    sem_destroy(&coronaPatient);
    sem_destroy(&fluPatient);
    system("pause");
}
//done
